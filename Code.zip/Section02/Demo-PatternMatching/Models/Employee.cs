﻿
namespace Packtpub.KunalChowdhury.Demos
{
    class Employee : Person
    {
        public string Designation { get; set; }
    }
}
