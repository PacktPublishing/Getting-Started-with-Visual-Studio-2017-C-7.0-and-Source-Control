﻿
namespace Packtpub.KunalChowdhury.Demos
{
    class Customer : Person
    {
        public bool IsPremium { get; set; }
    }
}
